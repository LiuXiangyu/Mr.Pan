<?php
namespace Admin\Model;
use Think\Model;

class InfoCommentModel extends Model{
	
}