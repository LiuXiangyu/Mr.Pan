<?php
return array(

    'MAIL_HOST' =>'smtp.sina.com',//smtp服务器的名称
    'MAIL_SMTPAUTH' =>TRUE, //启用smtp认证
    'MAIL_USERNAME' =>'liujan511536@sina.com',//你的邮箱名
    'MAIL_FROM' =>'liujan511536@sina.com',//发件人地址
    'MAIL_FROMNAME'=>'liujan',//发件人姓名
    'MAIL_PASSWORD' =>'liu511536',//这里已被我该了
    'MAIL_CHARSET' =>'utf-8',//设置邮件编码
    'MAIL_ISHTML' =>TRUE, // 是否HTML格式邮件
);

?>