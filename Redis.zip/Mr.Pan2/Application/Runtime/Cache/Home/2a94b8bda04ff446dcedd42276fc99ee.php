<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="/Mr.Pan2/Public/css/normalize.css" />
		<link rel="stylesheet" href="/Mr.Pan2/Public/css/general.css" />
		<link rel="stylesheet" href="/Mr.Pan2/Public/css/index.css" />
		<link rel="stylesheet" type="text/css" href="/Mr.Pan2/Public/css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="/Mr.Pan2/Public/css/bootstrap.css"/>
		<link rel="stylesheet" type="text/css" href="/Mr.Pan2/Public/css/style2.css"/>
		<link rel="stylesheet" type="text/css" href="/Mr.Pan2/Public/css/tmp.css"/>
		
	</head>
	<body>
		<div id="top-bar">
			<div class="wrap">
				<div class="top-bar-left">
					<form method="GET" action=<?php echo U("Home/Search/SearchResult")?> >
						<span class="logo"><a href='<?php echo U('Home/index/Index')?>'>教师评价系统</a></span>
						<input type="search" name="keyword" class="searchkey text-control" placeholder="搜索教师或课程"/>
						<input type="radio" name="searchType" value="teacher" checked="checked" />&nbsp教师
						<input type="radio" name="searchType" value="course" />&nbsp课程
						<input type="submit" class=" zu-top-add-question" value="搜索">
					</form>
				</div>
				<div class="top-bar-right">
					<?php  if (isLogin()) { ?>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-user"></i> <?php echo session("user_name");?><b class="caret"></b></a>
							<ul class="dropdown-menu">
		                       	<li><a href="<?php  echo U('Comment/manageComment') ?>"><i class="glyphicon glyphicon-cog"></i> 我的评论</a>
		                       		<li><a href="<?php  echo U('User/showInfo') ?>"><i class="glyphicon glyphicon-edit"></i> 个人信息</a></li>
		                       	<li><a href="<?php  echo U('User/followList') ?>"><i class="glyphicon glyphicon-heart"></i> 我的关注</a>
		                  	</ul>

						</li>
						<li>
							<a href="<?php echo U('User/logout')?>" class="logout"><i class="glyphicon glyphicon-off"></i> 注销</a>
						</li>
					</ul>
					<?php } else { ?>
						<ul class="nav navbar-nav navbar-right">
							<li>
								<a href="<?php echo U('User/login')?>" class="logout"><i class="glyphicon glyphicon-off"></i> 登陆</a>
							</li>
						</ul>		
					<?php } ?>
				</div>
			</div>
		</div>
		<div class="wrap" id="main">
			<form action=<?php echo U("index") ?> method="post" id="formid">

				
					<label class="mylabel-contrl">学校：</label>
					
						<select id="school" name="school_id" class="select-control" >
							<option selected="selected" value="">---</option>
							<?php foreach ($school as $key => $value): ?>
							<option value=<?php echo $key ?> >
							<?php echo $value ?>
							</option> 			
							<?php endforeach;?>
						</select>
					

					<label class="mylabel-contrl">学院：</label>
					
						<select id="college" name="college_id" class="select-control">
							<option selected="selected" value="">---</option>
						</select>
					

					<label class="mylabel-contrl">教师：</label>
				
						<select id="teacher" name="teacher_id" class="select-control" >
							<option selected="selected" value="">---</option>
							
						</select>
					

					<label class="mylabel-contrl">课程：</label>
					
						<select id="course" name="course_id" class="select-control">
							<option selected="selected" value="">---</option>
						</select>				
	
				<div id="txt">
					<textarea name="comment_content" rows="6" cols="100" onfocus="if (value =='请填写评论..'){value =''}"
	    				onblur="if (value ==''){value=''}"  class="form-control" placeholder="请填写评论.."></textarea>
	    		</div>
	    		<br/>
				<p><input type="submit" value="确认" class="btn btn-info" id="addbtn"/></p>
			</form>

			<?php foreach ($comment as $num => $record): ?>
				<div id="comment">
					<div class="comment_item" >
		    			<div class="content">
		        			<h3>
		        				<span class="info1">
		            				<span class="comment_username"><?php echo $record["username"] ?></span>
		            				<span class="time"><?php echo $record["time"] ?></span>
		            				<span class="time"><a href="<?php echo U('User/follow').'?user_id='.$record['user_id']; ?>">+关注 </a></span>
		            				<span class="time"><a href="<?php echo U('Comment/report').'?user_id='.$record['user_id'].'&comment_id='.$record['comment_id']; ?>">·举报 </a></span>
		            			</span>
		            			<span class="info2">
		                			<span class="comment_school"><?php echo $record["school"] ?></span>
		                			<span class="comment_college"><?php echo $record["college"] ?></span>
		                			<span class="comment_teacher"><?php echo $record["teacher"] ?></span>
		                			<span class="comment_course"><?php echo $record["course"] ?></span>
		                		</span>
		                			
		        			</h3>
		        			<p class=""><?php echo $record["content"] ?>
		        			</p>
		    			</div>
					</div>
				</div>
			<?php endforeach; ?>

			<div id="pagenav">
        	</div>
		</div>
		<script type="text/javascript" src="/Mr.Pan2/Public/js/jquery-2.1.4.min.js"></script>
		<script	type="text/javascript" src="/Mr.Pan2/Public/js/general.js"></script>
		<script	type="text/javascript" src="/Mr.Pan2/Public/js/index.js"></script>
		<script type="text/javascript" src="/Mr.Pan2/Public/js/bootstrap-dropdown.js"></script>
	</body>
</html>